config = { 
'FLASK_ENV':'DEVELOPMENT',
'FLASK_APP':'sa',
'FLASK_DEBUG':'1',
}
